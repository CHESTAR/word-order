'use babel';

import WordOrderInverterView from '../lib/word-order-inverter-view';

describe('WordOrderInverterView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
